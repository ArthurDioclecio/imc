// app/layout.tsx
import { useNavigation } from '@react-navigation/native';
import { createDrawerNavigator } from '@react-navigation/drawer';
import HomeScreen from './index'; // Tela inicial
import settings from '../user'; // Ota tela


const Drawer = createDrawerNavigator();

export default function Layout() {
  return (
    <Drawer.Navigator initialRouteName="Home">
      <Drawer.Screen name="Home" component={HomeScreen} />
      <Drawer.Screen name="Configuraçoes" component={settings} />
    </Drawer.Navigator>
  );
}