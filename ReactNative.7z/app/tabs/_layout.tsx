import React, { useState } from 'react';
import { View, useWindowDimensions } from 'react-native';
import { TabView, SceneMap, TabBar } from 'react-native-tab-view';
import Index from './index'; 
import Settings from '../settings'; 
import User from '../user'; 

export default function TabsLayout() {
  const layout = useWindowDimensions();
  const [index, setIndex] = useState(0);

  const [routes] = useState([
    { key: 'settings', title: 'configuraçoes' },
    { key: 'home', title: 'Imc' },
    { key: 'user', title: 'User' },
     
  ]);

  const renderScene = SceneMap({
   
     user: User,
      home: Index,
    settings: Settings,
  });

  return (
    <TabView
      navigationState={{ index, routes }}
      renderScene={renderScene}
      onIndexChange={setIndex}
      initialLayout={{ width: layout.width }}
      renderTabBar={(props) => (
        <TabBar
          {...props}
          indicatorStyle={{ backgroundColor: 'white' }}
          style={{ backgroundColor: '#2196f3' }}
        />
      )}
    />
  );
}