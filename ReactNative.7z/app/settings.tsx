import React from "react";
import { Text, View } from "react-native";

export default function TabSettings() {
    return(
        <View>
            <Text>Aba Configurações</Text>
        </View>
    );
}
